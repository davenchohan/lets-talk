/*
 * Filename: lets-talk.c
 * Description: Chatbot
 * Date: June 25, 2022
 * Name: Daven Chohan
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>  
#include <sys/socket.h>
#include <unistd.h>
#include <ctype.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include "list.h"

#define INPUT_BUFFER_SIZE 100
#define UDP_BUFFER_SIZE 64000

int finished = 0; //0 is false 1 is true, determines if the chat is finished
int dont_read = 0; //Exit command was received or sent

int sockfd;
struct sockaddr_in receiver_addr, sender_addr;
struct sockaddr_storage storage;
pthread_t sender, receiver, input, output;

struct addrinfo *servinfo, hints, *p;

List* sent_list;
List* receive_list;

pthread_mutex_t sent_mutex, receive_mutex;

char* received_message;
char* user_input;

int other_user_status = 0; //Updates if the other user is online
int status_update = 0; //Updates that this user is online


//Function Declarations

void* read_input(void* ptr);
void* print_msg(void* ptr);
void* encrypt(char* word);
void* decrypt(char* word);
void* end_connection();
void* read_input(void* ptr);
void* print_msg(void* ptr);
void* start_sending(void* args);
void* start_receiving(void* args);
void * initialize_sender(char* address, char* port);
void * initialize_receiver(int port);

//Encrypt the sent message
void* encrypt(char* word){
    for (int i = 0; i < strlen(word); ++i)
    {
        //if (isalpha(word[i]) != 0)
        //{
         //   word[i] = word[i]+ (27 % 256);
        //}
        word[i]++;
    }
    return 0;
}

//Decrypt the received message
void* decrypt(char* word){
    for (int i = 0; i < strlen(word); ++i)
    {
        //if (isalpha(word[i]) != 0)
        //{
        //    word[i] = word[i]- (27 % 256);
        //}
        word[i]--;
    }
    return 0;
}

//End the connection
void* end_connection(){
    free(received_message);
    free(user_input);
    finished = 1;
    List_free(sent_list, NULL);
    List_free(receive_list, NULL);
    int close(int sockfd);
    fflush(stdout);
    //exit(EXIT_SUCCESS);
}

//Read the user input
void* read_input(void* ptr){
    user_input = NULL;
    while(!finished && !dont_read){
        char buffer[INPUT_BUFFER_SIZE];
        int bufferlength = 0;
        int inputlength = 0;
        char* lines;
        if (List_count(sent_list) < 1)
        {
            do {
                fgets(buffer, INPUT_BUFFER_SIZE, stdin); // get buffer amount of characters characters
                bufferlength = strlen(buffer);
                if (!user_input)
                {
                    user_input = malloc(bufferlength+1); //malloc memory for first buffer amount of char
                }
                else {
                    user_input = realloc(user_input, bufferlength+inputlength+1); //realloc memory for next buffer amount of char
                }
                strcpy(user_input+inputlength, buffer); //copy the chars back to input
                inputlength += bufferlength;
            } while(bufferlength == INPUT_BUFFER_SIZE - 1); //while there are still characters left
            status_update = 1;
            if (strcmp(user_input, "!exit\n") == 0)
            {
                dont_read = 1;
            }
            lines = strtok(user_input, "\n");
            pthread_mutex_lock(&sent_mutex);
            while(lines != NULL){
                List_append(sent_list, lines);
                lines = strtok(NULL, "\n");
            }
            pthread_mutex_unlock(&sent_mutex);
        }
        //free(user_input);
    }
    return 0;
}

//Print the received messages
void* print_msg(void* ptr) {
    while(!finished){
        pthread_mutex_lock(&receive_mutex);
        char* message = List_trim(receive_list);
        pthread_mutex_unlock(&receive_mutex);
        if (message != NULL)
        {
            if (strcmp(message, "!status") != 0 && (strcmp(message, "") != 0)) //Status will only print locally
            {
                printf("%s\n", message);
            }
            else{
                pthread_mutex_lock(&receive_mutex);
                char status_command[] = "";
                List_append(sent_list, status_command);
                pthread_mutex_unlock(&receive_mutex);
            }
            if (strcmp(message, "!exit") == 0)
            {
                end_connection();
            }
            //free(message);
            fflush(stdout);
        }
    }
}

//Start sending any messages inputted by the user
void* start_sending(void* args){
    char exit_command[] = "!exit";
    char status_command[] = "!status";
    List_append(sent_list, status_command); //used to tell other server that its online initially
    encrypt(exit_command);
    //encrypt(status_command);
    while(!finished){
        char* sent_message;
        if (List_count(sent_list) > 0)
        {
            pthread_mutex_lock(&sent_mutex);
            sent_message = List_trim(sent_list);
            pthread_mutex_unlock(&sent_mutex);
            int len = strlen(sent_message);
            encrypt(sent_message);
            int send = sendto(sockfd, sent_message, len, 0, p->ai_addr, p->ai_addrlen);
            //printf("%s\n", "sent the message");
            if (send < 0)
            {
                perror("Sendto error");
                exit(EXIT_FAILURE);
            }
            if (strcmp(sent_message, exit_command) == 0)
            {
                end_connection();
            }
            decrypt(sent_message);
            if ((strcmp(sent_message, status_command) == 0) && (status_update == 1))
            {
                if (other_user_status == 0)
                {
                    char* status = "Offline";
                    List_append(receive_list, status);
                    //printf("%s\n", status);
                } else {
                    char* status = "Online";
                    List_append(receive_list, status);
                    //printf("%s\n", status);
                }
            }
            //free(sent_message);
        }
    }
}

//Start receiving messages from the other user
void* start_receiving(void* args){
     while(!finished && !dont_read){
        received_message = malloc(sizeof(char*)*UDP_BUFFER_SIZE);
        socklen_t addr_len = sizeof(struct sockaddr_in);
        int receive = recvfrom(sockfd, received_message, UDP_BUFFER_SIZE, 0, (struct sockaddr*)&storage, &addr_len);
        //printf("%s\n", "received the message");
        if (receive < 0)
        {
            perror("Recvfrom error");
            exit(EXIT_FAILURE);
        }
        other_user_status = 1; //Other user is now online
        decrypt(received_message);
        if (strcmp(received_message, "!exit") == 0)
        {
            dont_read = 1;
        }
        pthread_mutex_lock(&receive_mutex);
        List_append(receive_list, received_message);
        pthread_mutex_unlock(&receive_mutex);
        //free(received_message);
    }
}

//Create the sender port
//Partly learned from http://beej.us/guide/bgnet/ on how to get the address from a valid host name.
//Partly learned from https://linux.die.net/man/3/getaddrinfo
void * initialize_sender(char* address, char* port) {
    //memset(&sender_addr, 0, sizeof sender_addr);
    //sender_addr.sin_family = AF_INET;
    //sender_addr.sin_port = htons(port);
    //sender_addr.sin_addr.s_addr = inet_addr(address);

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_DGRAM;
    int addr = getaddrinfo(address, port, &hints, &servinfo);
    if (addr != 0)
    {
        printf("%s\n", "getaddrinfo sender error");
        exit(EXIT_FAILURE);
    }
    for (p = servinfo; p != NULL; p->ai_next)
    {
        if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1)
        {
            perror("initialize socket error");
            continue;
        }


        break;
    }
    if (p==NULL)
    {
        printf("%s\n", "idk what sender error");
        exit(EXIT_FAILURE);
    }
    sent_list = List_create();
    freeaddrinfo(servinfo);

}

//Create the receiver port
void * initialize_receiver(int port) {

    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
    memset(&receiver_addr, 0, sizeof receiver_addr);
    receiver_addr.sin_family = AF_INET;
    receiver_addr.sin_port = htons(port);
    receiver_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    int bind_attempt;
    if ( (bind_attempt = bind(sockfd, (struct sockaddr*) &receiver_addr, sizeof(receiver_addr))) < 0 ) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }
    receive_list = List_create();
}                                       

void main(int argc, char *argv[])
{

    if (argc == 4)
    {
        printf("%s\n", "Welcome to LetS-Talk! Please type your messages now.");
        int local_port = atoi(argv[1]);
        char* sendto_port = argv[3];
        char* sendto_address = argv[2];
        pthread_mutex_init(&sent_mutex, NULL);
        pthread_mutex_init(&receive_mutex, NULL);
        initialize_sender(sendto_address, sendto_port);
        initialize_receiver(local_port);
        pthread_create(&receiver, NULL, start_receiving, NULL);
        pthread_create(&sender, NULL, start_sending, NULL);
        pthread_create(&input, NULL, read_input, NULL);
        pthread_create(&output, NULL, print_msg, NULL);
        while(!finished);
    } else {
        printf("%s\n", "Provide the correct arguments");
    }
    pthread_cancel(input); //Cancel because of fgets waiting for input
    pthread_cancel(receiver); //Cancel because of recvfrom waiting for message
    pthread_join(sender, NULL);
    //printf("%s\n", "ended connection 1");
    pthread_join(output, NULL);
    //printf("%s\n", "ended connection 2");
    pthread_join(input, NULL);
    //printf("%s\n", "ended connection 3");
    pthread_join(receiver, NULL);
    //printf("%s\n", "ended connection 4");
    return;
}